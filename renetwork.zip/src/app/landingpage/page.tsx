import FreeioLandingPage from '@/components/freeio/FreeioLandingPage'
import React from 'react'

const LandingPage = () => {
  return (
    <div>
      <FreeioLandingPage />
    </div>
  )
}

export default LandingPage
